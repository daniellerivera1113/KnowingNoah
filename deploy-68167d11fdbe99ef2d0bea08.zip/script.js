// Mobile-friendly toggle accordion function
            function toggleAccordion(contentId) {
                // Get the accordion content
                var content = document.getElementById(contentId);
                
                // Toggle display
                if (content.style.display === "block") {
                    content.style.display = "none";
                } else {
                    content.style.display = "block";
                }
                
                // Prevent default behavior to ensure it works on touch devices
                event.preventDefault();
                return false;
            }
            
            // Mobile-friendly tab switching function
            function openSimpleTab(tabId) {
                // Hide all tab content
                var tabContents = document.getElementsByClassName("simple-tab-content");
                for (var i = 0; i < tabContents.length; i++) {
                    tabContents[i].style.display = "none";
                }
                
                // Remove active class from all buttons
                var tabButtons = document.getElementsByClassName("simple-tab-button");
                for (var i = 0; i < tabButtons.length; i++) {
                    tabButtons[i].classList.remove("active");
                }
                
                // Show the selected tab and set button as active
                document.getElementById(tabId).style.display = "block";
                
                // Find the button that opened this tab and add active class
                for (var i = 0; i < tabButtons.length; i++) {
                    if (tabButtons[i].getAttribute("onclick").includes(tabId)) {
                        tabButtons[i].classList.add("active");
                    }
                }
                
                // Prevent default behavior for mobile compatibility
                if (event) {
                    event.preventDefault();
                }
                return false;
            }
            
            
            // Initialize accordion and tabs on page load
            document.addEventListener("DOMContentLoaded", function() {
                // Open first accordion item
                document.getElementById("overview-content").style.display = "block";
                
                // Make sure first tab is active and showing content
                document.getElementById("therapeutic-schools").style.display = "block";
                
                // Add touch event listeners to all buttons for iOS compatibility
                var allButtons = document.querySelectorAll('.accordion-button, .simple-tab-button');
                for (var i = 0; i < allButtons.length; i++) {
                    allButtons[i].addEventListener('touchend', function(e) {
                        // Simulate click on touchend for iOS
                        this.click();
                        e.preventDefault();
                    });
                }
            });